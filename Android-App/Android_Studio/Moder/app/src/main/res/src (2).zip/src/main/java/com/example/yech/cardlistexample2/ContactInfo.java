package com.example.yech.cardlistexample2;

import android.widget.ImageView;

/**
 * Created by Yech on 3/28/2015.
 */
//This class just is a data structure to hold the data that is to be in the card.
public class ContactInfo {
    protected String name;
    protected String surname;
    protected String email;
    protected Integer progress;
    protected String image;


    protected static final String NAME_PREFIX = "Name_";
    protected static final String SURNAME_PREFIX = "Surname_";
    protected static final String EMAIL_PREFIX = "email_";
}
