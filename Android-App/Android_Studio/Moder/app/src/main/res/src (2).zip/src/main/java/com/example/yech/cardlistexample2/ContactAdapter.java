package com.example.yech.cardlistexample2;

/**
 * Created by Yech on 3/28/2015.
 */
/*
 * Copyright (C) 2014 Francesco Azzola
 *  Surviving with Android (http://www.survivingwithandroid.com)
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Transformation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;


import org.w3c.dom.Text;

import java.util.List;

public class ContactAdapter extends RecyclerView.Adapter<ContactAdapter.ContactViewHolder> {

    private List<ContactInfo> contactList;
    protected TextView expandable;
    protected Context context;

    public ContactAdapter(List<ContactInfo> contactList, Context con) {
        this.contactList = contactList;
        context = con;
    }


    @Override
    public int getItemCount() {
        return contactList.size();
    }

    @Override
    //this method is called when a card is created. It is where you set the card elements.
    public void onBindViewHolder(ContactViewHolder contactViewHolder, int i) {
        //i is the index in the list that this specific card is.
        ContactInfo ci = contactList.get(i);
        //Access the Ui elements through an instance of the contactViewHolder, which is essentially a card.
        contactViewHolder.vName.setText(ci.image);
        contactViewHolder.vSurname.setText(ci.surname);
        contactViewHolder.vEmail.setText(ci.email);
        contactViewHolder.vTitle.setText(ci.name + " " + ci.surname);
        //This is just a little code to display different images in the example.
        /*if(i%5==0)
            contactViewHolder.image.setImageResource(R.drawable.test0);
        else if(i%5==1)
            contactViewHolder.image.setImageResource(R.drawable.test1);
        else if(i%5==2)
            contactViewHolder.image.setImageResource(R.drawable.test2);
        else if(i%5==3)
            contactViewHolder.image.setImageResource(R.drawable.test3);
        else if(i%5==4)
            contactViewHolder.image.setImageResource(R.drawable.test4);*/

        //Progress bar stuff.
        ProgressBarAnimation anim = new ProgressBarAnimation(contactViewHolder.progress, 0, ci.progress);
        anim.setDuration(10000);
        anim.setInterpolator(new DecelerateInterpolator());
        contactViewHolder.progress.startAnimation(anim);

        /*final LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        TextView tv = (TextView)inflater.inflate(R.layout.text_view, null);

        RelativeLayout layout = (RelativeLayout) context.findViewById(R.id.layout420);
        layout.addView(tv,new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT));*/


    }


    @Override
    public ContactViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View itemView = LayoutInflater.
                from(viewGroup.getContext()).
                inflate(R.layout.card_layout, viewGroup, false);

        return new ContactViewHolder(itemView);
    }

    public static class ContactViewHolder extends RecyclerView.ViewHolder {

        protected TextView vName;
        protected TextView vSurname;
        protected TextView vEmail;
        protected TextView vTitle;
        protected ProgressBar progress;
        protected ImageView image;
        protected RelativeLayout layout;
        Button help_title_gest;
        TextView txt_help_gest;

        //This class finds the ui elements of the card and links them to variables.
        public ContactViewHolder(View v) {
            super(v);
            vName = (TextView) v.findViewById(R.id.txtName);
            vSurname = (TextView) v.findViewById(R.id.txtSurname);
            vEmail = (TextView) v.findViewById(R.id.txtEmail);
            vTitle = (TextView) v.findViewById(R.id.title);
            progress = (ProgressBar) v.findViewById(R.id.progressBar420);
            image = (ImageView) v.findViewById(R.id.test_image420);
            layout = (RelativeLayout) v.findViewById(R.id.layout420);

            help_title_gest = (Button) v.findViewById(R.id.help_title_gest);
            txt_help_gest = (TextView) v.findViewById(R.id.txt_help_gest);
            txt_help_gest.setVisibility(View.GONE);

            help_title_gest.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    txt_help_gest.setVisibility(txt_help_gest.isShown()
                            ? View.GONE
                            : View.VISIBLE);
                }
            });

        }
    }

    //This allows you to implement the progress bar stuff.
    public class ProgressBarAnimation extends Animation {
        private ProgressBar progressBar;
        private float from;
        private float to;

        public ProgressBarAnimation(ProgressBar progressBar, float from, float to) {
            super();
            this.progressBar = progressBar;
            this.from = from;
            this.to = to;
        }

        @Override
        protected void applyTransformation(float interpolatedTime, Transformation t) {
            super.applyTransformation(interpolatedTime, t);
            float value = from + (to - from) * interpolatedTime;
            progressBar.setProgress((int) value);
        }

    }
}